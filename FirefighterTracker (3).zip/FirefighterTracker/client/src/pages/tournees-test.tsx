export default function TourneesTestPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Test Tournées</h1>
      <p>Cette page de test fonctionne !</p>
    </div>
  );
}