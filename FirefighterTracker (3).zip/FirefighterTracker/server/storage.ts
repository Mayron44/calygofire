import { drizzle } from "drizzle-orm/neon-http";
import { neon } from "@neondatabase/serverless";
import { eq, and, desc, asc, ilike, inArray, gte, lte } from "drizzle-orm";
import { users, addresses, visits, sales, tournees, type User, type InsertUser, type Address, type InsertAddress, type Visit, type InsertVisit, type Sale, type InsertSale, type Tournee, type InsertTournee } from "@shared/schema";

// Use local database for now, will migrate to Supabase once connection is stable
const DATABASE_URL = process.env.DATABASE_URL!;

const sql = neon(DATABASE_URL);
const db = drizzle(sql);

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User>;
  approveUser(id: number, approvedBy: number): Promise<User>;
  getUnapprovedUsers(): Promise<User[]>;
  getAllUsers(): Promise<User[]>;
  
  // Addresses
  getAddresses(filters?: { status?: string; assignedTo?: number; city?: string }): Promise<Address[]>;
  getAddress(id: number): Promise<Address | undefined>;
  createAddress(address: InsertAddress): Promise<Address>;
  updateAddress(id: number, address: Partial<InsertAddress>): Promise<Address>;
  deleteAddress(id: number): Promise<void>;
  getAddressesByBounds(bounds: { north: number; south: number; east: number; west: number }): Promise<Address[]>;
  
  // Visits
  getVisits(addressId?: number, pompierId?: number): Promise<Visit[]>;
  createVisit(visit: InsertVisit): Promise<Visit>;
  getVisitsByAddress(addressId: number): Promise<Visit[]>;
  
  // Sales
  getSales(filters?: { pompierId?: number; startDate?: Date; endDate?: Date }): Promise<Sale[]>;
  createSale(sale: InsertSale): Promise<Sale>;
  getSalesStats(): Promise<{ totalSales: number; totalAmount: number; calendarsSold: number }>;
  
  // Tournees
  getTournees(pompierId?: number): Promise<Tournee[]>;
  createTournee(tournee: InsertTournee): Promise<Tournee>;
  updateTournee(id: number, tournee: Partial<InsertTournee>): Promise<Tournee>;
  deleteTournee(id: number): Promise<void>;
}

export class DrizzleStorage implements IStorage {
  // Users
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.email, email));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, user: Partial<InsertUser>): Promise<User> {
    const result = await db.update(users).set(user).where(eq(users.id, id)).returning();
    return result[0];
  }

  async approveUser(id: number, approvedBy: number): Promise<User> {
    const result = await db.update(users).set({ 
      isApproved: true, 
      approvedBy: approvedBy 
    }).where(eq(users.id, id)).returning();
    return result[0];
  }

  async getUnapprovedUsers(): Promise<User[]> {
    return await db.select().from(users).where(eq(users.isApproved, false));
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(asc(users.createdAt));
  }

  // Addresses
  async getAddresses(filters?: { status?: string; assignedTo?: number; city?: string }): Promise<Address[]> {
    let conditions = [];
    
    if (filters?.status) {
      conditions.push(eq(addresses.status, filters.status));
    }
    if (filters?.assignedTo) {
      conditions.push(eq(addresses.assignedTo, filters.assignedTo));
    }
    if (filters?.city) {
      conditions.push(eq(addresses.city, filters.city));
    }
    
    if (conditions.length > 0) {
      return await db.select().from(addresses).where(and(...conditions)).orderBy(asc(addresses.createdAt));
    }
    
    return await db.select().from(addresses).orderBy(asc(addresses.createdAt));
  }

  async getAddress(id: number): Promise<Address | undefined> {
    const result = await db.select().from(addresses).where(eq(addresses.id, id));
    return result[0];
  }

  async createAddress(address: InsertAddress): Promise<Address> {
    const result = await db.insert(addresses).values(address).returning();
    return result[0];
  }

  async updateAddress(id: number, address: Partial<InsertAddress>): Promise<Address> {
    const result = await db.update(addresses).set(address).where(eq(addresses.id, id)).returning();
    return result[0];
  }

  async deleteAddress(id: number): Promise<void> {
    await db.delete(addresses).where(eq(addresses.id, id));
  }

  async getAddressesByBounds(bounds: { north: number; south: number; east: number; west: number }): Promise<Address[]> {
    return await db.select().from(addresses).where(
      and(
        gte(addresses.latitude, bounds.south.toString()),
        lte(addresses.latitude, bounds.north.toString()),
        gte(addresses.longitude, bounds.west.toString()),
        lte(addresses.longitude, bounds.east.toString())
      )
    );
  }

  // Visits
  async getVisits(addressId?: number, pompierId?: number): Promise<Visit[]> {
    let conditions = [];
    
    if (addressId) {
      conditions.push(eq(visits.addressId, addressId));
    }
    if (pompierId) {
      conditions.push(eq(visits.pompierId, pompierId));
    }
    
    if (conditions.length > 0) {
      return await db.select().from(visits).where(and(...conditions)).orderBy(desc(visits.createdAt));
    }
    
    return await db.select().from(visits).orderBy(desc(visits.createdAt));
  }

  async createVisit(visit: InsertVisit): Promise<Visit> {
    const result = await db.insert(visits).values(visit).returning();
    return result[0];
  }

  async getVisitsByAddress(addressId: number): Promise<Visit[]> {
    return await db.select().from(visits).where(eq(visits.addressId, addressId)).orderBy(desc(visits.createdAt));
  }

  // Sales
  async getSales(filters?: { pompierId?: number; startDate?: Date; endDate?: Date }): Promise<Sale[]> {
    let conditions = [];
    
    if (filters?.pompierId) {
      conditions.push(eq(sales.pompierId, filters.pompierId));
    }
    if (filters?.startDate) {
      conditions.push(gte(sales.createdAt, filters.startDate));
    }
    if (filters?.endDate) {
      conditions.push(lte(sales.createdAt, filters.endDate));
    }
    
    if (conditions.length > 0) {
      return await db.select().from(sales).where(and(...conditions)).orderBy(desc(sales.createdAt));
    }
    
    return await db.select().from(sales).orderBy(desc(sales.createdAt));
  }

  async createSale(sale: InsertSale): Promise<Sale> {
    const result = await db.insert(sales).values(sale).returning();
    return result[0];
  }

  async getSalesStats(): Promise<{ totalSales: number; totalAmount: number; calendarsSold: number }> {
    const result = await db.select().from(sales);
    
    const totalSales = result.length;
    const totalAmount = result.reduce((sum, sale) => sum + parseFloat(sale.amount), 0);
    const calendarsSold = totalSales; // Assuming each sale = 1 calendar
    
    return {
      totalSales,
      totalAmount,
      calendarsSold
    };
  }

  // Tournees
  async getTournees(pompierId?: number): Promise<Tournee[]> {
    if (pompierId) {
      return await db.select().from(tournees).where(eq(tournees.pompierId, pompierId)).orderBy(desc(tournees.createdAt));
    }
    
    return await db.select().from(tournees).orderBy(desc(tournees.createdAt));
  }

  async createTournee(tournee: InsertTournee): Promise<Tournee> {
    const result = await db.insert(tournees).values(tournee).returning();
    return result[0];
  }

  async updateTournee(id: number, tournee: Partial<InsertTournee>): Promise<Tournee> {
    const result = await db.update(tournees).set(tournee).where(eq(tournees.id, id)).returning();
    return result[0];
  }

  async deleteTournee(id: number): Promise<void> {
    await db.delete(tournees).where(eq(tournees.id, id));
  }
}

export const storage = new DrizzleStorage();